/**
 * Car - This class initializes methods for the Car object, also initialized by the Car constructor.
 * This whole class pretty much covers the entirety of Step 1: Car Class and Part 1 of Step 8: Extend our aOrderedList class.
 *
 * CSC 1351 Programming Project No. 1 Part A
 * Section 002
 *
 * @author Madison Harman
 * @since 03/17/2024
 *
 */

public class Car implements Comparable<Car> {
	private String make;
	private int year;
	private int price;

	/**
	 * Car - Constructor that sets the values of make, year, and price
	 *
	 * CSC 1351 Programming Project No. 1 Part A
	 * Section 002
	 *
	 * @author Madison Harman
	 * @since 03/17/2024
	 *
	 */

	public Car(String Make, int Year, int Price) {
		make = Make;
		year = Year;
		price = Price;
	}

	/**
	 * getMake - Returns the value of make.
	 * @return - The value of make.
	 *
	 * CSC 1351 Programming Project No. 1 Part A
	 * Section 002
	 *
	 * @author Madison Harman
	 * @since 03/17/2024
	 *
	 */

	public String getMake() {
		return make;
	}

	/**
	 * getYear - Returns the value of year.
	 * @return - The value of year.
	 *
	 * CSC 1351 Programming Project No. 1 Part A
	 * Section 002
	 *
	 * @author Madison Harman
	 * @since 03/17/2024
	 *
	 */

	public int getYear() {
		return year;
	}

	/**
	 * getPrice - Returns the value of price.
	 * @return - The value of price.
	 *
	 * CSC 1351 Programming Project No. 1 Part A
	 * Section 002
	 *
	 * @author Madison Harman
	 * @since 03/17/2024
	 *
	 */

	public int getPrice() {
		return price;
	}

	/**
	 * compareTo - Compares two cars based on make and year.
	 * @param other - The other car that is being compared.
	 * @return - Firstly, if the makes are the same, it compares the years.
	 * Returns 1 if the make is greater (alphabetically) and -1 otherwise.
	 * 
	 * CSC 1351 Programming Project No. 1 Part A
	 * Section 002
	 *
	 * @author Madison Harman
	 * @since 03/17/2024
	 *
	 */

	@Override
	public int compareTo(Car other) {
		// If the makes are the same, it compares the years.
		if(make.compareTo(other.make) == 0) {
			return Integer.compare(year, other.year);
		}
		// Else, it returns 1 if the make is greater (alphabetically) and -1 otherwise.
		else {
			return make.compareTo(other.make);
		}
	}

	/**
	 * toString - Returns the following string: “Make: “ + make + “, Year : “ + year + “, Price: “ + price + “;”
	 * @return - The following string: “Make: “ + make + “, Year : “ + year + “, Price: “ + price + “;”
	 *
	 * CSC 1351 Programming Project No. 1 Part A
	 * Section 002
	 *
	 * @author Madison Harman
	 * @since 03/17/2024
	 *
	 */

	@Override
	public String toString() {
		return "Make: " + make + ", Year: " + year + ", Price: " + price;
	}
}